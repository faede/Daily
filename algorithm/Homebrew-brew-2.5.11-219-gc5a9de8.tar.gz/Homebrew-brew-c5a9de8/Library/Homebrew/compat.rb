# typed: strict
# frozen_string_literal: true

require "compat/cli/parser"
require "compat/formula"
require "compat/global"
