# typed: true
# frozen_string_literal: true

# Helper functions for querying operating system information.
#
# @api private
module OS
  # Check if the operating system is macOS.
  #
  # @api public
  def self.mac?
    return false if ENV["HOMEBREW_TEST_GENERIC_OS"]

    RbConfig::CONFIG["host_os"].include? "darwin"
  end

  # Check if the operating system is Linux.
  #
  # @api public
  def self.linux?
    return false if ENV["HOMEBREW_TEST_GENERIC_OS"]

    RbConfig::CONFIG["host_os"].include? "linux"
  end

  # Get the kernel version.
  #
  # @api public
  def self.kernel_version
    @kernel_version ||= Version.new(Utils.safe_popen_read("uname", "-r").chomp)
  end

  ::OS_VERSION = ENV["HOMEBREW_OS_VERSION"]

  if OS.mac?
    require "os/mac"
    # Don't tell people to report issues on unsupported configurations.
    if !OS::Mac.prerelease? &&
       !OS::Mac.outdated_release? &&
       ARGV.none? { |v| v.start_with?("--cc=") } &&
       ENV["HOMEBREW_PREFIX"] == "/usr/local"
      ISSUES_URL = "https://docs.brew.sh/Troubleshooting"
    end
    PATH_OPEN = "/usr/bin/open"
  elsif OS.linux?
    require "os/linux"
    ISSUES_URL = "https://docs.brew.sh/Troubleshooting"
    PATH_OPEN = "xdg-open"
  end
end
